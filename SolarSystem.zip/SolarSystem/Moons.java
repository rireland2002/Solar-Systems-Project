public class Moons extends Planets//The Moon class extends planet
{
    private double centreOfRotationAngle;//A variable for the angle that which the moon orbits the planet
    private double centreOfRotationDistance;//The distance from the planet that the moon is orbiting

    public Moons(double distance, double angle, double diameter, String col, double centreOfRotationAngle, double centreOfRotationDistance)//Constructor for the moon
    {
        super(distance, angle, diameter, col);// The super contructor from planets
        this.centreOfRotationAngle = centreOfRotationAngle;//Setting the new centre variables
        this.centreOfRotationDistance = centreOfRotationDistance;
    }

    public double getCentreAngle()//Methods to return the centre variables
    {
        return centreOfRotationAngle;
    }

    public double getCentreDistance()
    {
        return centreOfRotationDistance;
    }

}
