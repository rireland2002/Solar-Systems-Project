public class Planets extends Sun//Planets extend sun and orbit the sun
{
    public Planets(double distance, double angle, double diameter, String col)//The constructor for planets
    {
        super(distance, angle, diameter, col);// The super constructor from the Sun class
    }

}