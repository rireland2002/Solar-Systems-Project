public class SolarMain
{
    public static void main(String[] args) 
    {
      SolarSystem Solar1 = new SolarSystem(1000, 1000);//Create instance of solar system
      Sun sun1 = new Sun(0, 0, 30, "YELLOW");//Create an instance of sun
      Planets earth = new Planets(80,10,10,"GREEN");//Create instances of planet for all planets in solar system
      Planets mercury = new Planets(30,15,10,"GRAY");
      Planets venus = new Planets(50,27,12,"MAGENTA");
      Planets mars = new Planets(120,42,10,"ORANGE");
      Planets jupiter = new Planets(170, 132, 20, "MAGENTA");
      Planets saturn = new Planets(230,1,17,"PINK");
      Planets uranus = new Planets(290,29,10,"ORANGE");
      Planets neptune = new Planets(310,70,10,"WHITE");
      Planets pluto = new Planets(340,200,5,"BLUE");
      Moons moon1 = new Moons(20, 10, 5, "GRAY", earth.getAngle(),earth.getDistance());//Create an instance of moon, use earths angle and distance as parameters to ensure it orbits the earth
      Planets[] asteroids = new Planets[250];//Create an array of planets to simulate an asteroid belt
      Moons[] saturnRing = new Moons[400];//Create an array of moons to simulate saturns rings, they will orbit saturn
      
      for(int i = 0; i<250;i++)
        {
          asteroids[i] = new Planets(Math.random()*((156-131)+1)+131, Math.random()*361, Math.random()*6, "GRAY");//Create instances of the asteroids and use Math.random and a range to randomly place them around the solar system in a belt
        }

      for(int i = 0; i<400;i++)
        {
          saturnRing[i] = new Moons(Math.random()*((40-30)+1)+30, Math.random()*361, Math.random()*3, "WHITE",saturn.getAngle(),saturn.getDistance());//Create instances of moons to orbit around saturn also using Math and a range, use the angles and distance of saturn to ensure it orbits-- For some reason when using the methods for returning the centre varibales it doesn't work so I used the planets angle and distance variables instead
        }

      while(true)//A while loop to draw the solar objects continously
      {
        for(int i = 0; i<250;i++)
        {
          Solar1.drawSolarObject(asteroids[i].getDistance(), asteroids[i].getAngle(), asteroids[i].getDiameter(),asteroids[i].getCol());//Drawing all the asteroids in the asteroid belt
          asteroids[i].updateAngle(Math.random()*3);//Updates the angles of the asteroids in the belt at random speeds
        }
        for(int i = 0; i<400;i++)
        {
          Solar1.drawSolarObjectAbout(saturnRing[i].getDistance(), saturnRing[i].getAngle(), saturnRing[i].getDiameter(), saturnRing[i].getCol(), saturn.getDistance(), saturn.getAngle());//Draws all the asteroids in the saturn rings
          saturnRing[i].updateAngle(Math.random()*3);//Also randomly changes the angles but for the saturn rings
          
        }
        Solar1.drawSolarObject(sun1.getDistance(), sun1.getAngle(), sun1.getDiameter(), sun1.getCol());//Draws the sun using methods to get the variables and pass them to the drawSolarObject method, all the below are the same for different planets/moons
        Solar1.drawSolarObject(earth.getDistance(), earth.getAngle(), earth.getDiameter(),earth.getCol());
        Solar1.drawSolarObject(mercury.getDistance(), mercury.getAngle(), mercury.getDiameter(),mercury.getCol());
        Solar1.drawSolarObject(venus.getDistance(), venus.getAngle(), venus.getDiameter(),venus.getCol());
        Solar1.drawSolarObject(mars.getDistance(), mars.getAngle(), mars.getDiameter(),mars.getCol());
        Solar1.drawSolarObject(saturn.getDistance(), saturn.getAngle(), saturn.getDiameter(),saturn.getCol());
        Solar1.drawSolarObject(uranus.getDistance(), uranus.getAngle(), uranus.getDiameter(),uranus.getCol());
        Solar1.drawSolarObject(neptune.getDistance(),neptune.getAngle(), neptune.getDiameter(), neptune.getCol());
        Solar1.drawSolarObject(jupiter.getDistance(), jupiter.getAngle(), jupiter.getDiameter(), jupiter.getCol());
        Solar1.drawSolarObject(pluto.getDistance(), pluto.getAngle(), pluto.getDiameter(),pluto.getCol());
        Solar1.drawSolarObjectAbout(moon1.getDistance(), moon1.getAngle(), moon1.getDiameter(), moon1.getCol(), earth.getDistance(), earth.getAngle());//The same as above except uses the earths distance and angle as its centre variables to ensure it orbits the earth
        moon1.updateAngle(3);//Updates the angles at which the planets/moon orbit their solar objects
        jupiter.updateAngle(2);
        earth.updateAngle(1);
        mercury.updateAngle(2);
        mars.updateAngle(1);
        venus.updateAngle(3);
        saturn.updateAngle(1);
        uranus.updateAngle(2);
        neptune.updateAngle(1);
        pluto.updateAngle(1);
        Solar1.finishedDrawing();//Shows all objects that have been recently drawn
      }

    }
}