public class Sun
{
    private double distance;//The distance from the centre of the solar system  
    private double angle;//The angle the object is around the centre of the solar system
    private double diameter;//The size of the solar object
    private String col;//The colour of the solar object


    public Sun(double distance, double angle, double diameter, String col)//Constructor for the Sun class
    {
        this.distance = distance;//Setting all the parameters to the sun object
        this.angle = angle;
        this. diameter = diameter;
        this.col = col;
    }

    public double getDistance()//Method to return the distance variable
    {
        return distance;
    }

    public double getAngle()//Method to return the angle variable
    {
        return angle;
    }

    public double getDiameter()//Method to return the diameter variable
    {
        return diameter;
    }

    public String getCol()//Method to return the colour variable
    {
        return col;
    }

    public void updateAngle(double velocity)//Method to update the angle of a solar object to a variable speed- Would have thought this went in Planets as not needed by sun but told by TA's that this is the only option? Ask Joe Finney soon
    {
        angle += velocity;
    }
}
